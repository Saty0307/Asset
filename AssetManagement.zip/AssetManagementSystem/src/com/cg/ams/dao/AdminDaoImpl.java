package com.cg.ams.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.Asset_Allocation;

@Repository
public class AdminDaoImpl implements AdminDao 
{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void addAsset(Asset ast) 
	{
		em.persist(ast);
	}

	@Override
	public void delAsset(Integer astId) 
	{
		

	}

	@Override
	public Asset modAsset(Asset ast) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Asset fetchAsset(Integer ast) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Asset_Allocation> fetchAllAssetAllocation() {
		// TODO Auto-generated method stub
		return null;
	}

}
