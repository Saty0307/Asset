package com.cg.ams.dao;

import java.util.List;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.UserMaster;


public interface ManagerDao 
{
	void reqAsset(Integer astId);
	List<Asset> fetchRequestStatus();
	UserMaster fetchManager(String mgrname);
}
