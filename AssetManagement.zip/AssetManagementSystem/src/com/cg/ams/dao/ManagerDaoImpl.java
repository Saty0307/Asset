package com.cg.ams.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.UserMaster;

@Repository
public class ManagerDaoImpl implements ManagerDao
{
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public void reqAsset(Integer astId) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<Asset> fetchRequestStatus() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserMaster fetchManager(String mgrname) 
	{
		return null;
		

	}

}
