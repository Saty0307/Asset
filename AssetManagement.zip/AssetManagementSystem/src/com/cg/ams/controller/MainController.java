package com.cg.ams.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.UserMaster;
import com.cg.ams.service.AdminService;
import com.cg.ams.service.ManagerService;



@Controller
public class MainController 
{
	@Autowired
	AdminService ads;
	@Autowired
	ManagerService mgs;
	UserMaster usr=null;
	
	@RequestMapping("start")
	public String showLogin(Model model)
	{	
		UserMaster user= new UserMaster();
		model.addAttribute("user",user);
		return "login";		
	}
	
	
	//VERIFYING USER
	@RequestMapping("login")
	public String CheckUser(@Valid@ModelAttribute("user") UserMaster user,BindingResult res,Model model)
	{
		if(res.hasErrors())
		{
			model.addAttribute("user",user);
			return "adminMenu";
		}
		else
		{
			if(user.getUserType().equals("Admin"))
			if(user.getUserName().equals("admin")&& user.getUserPswd().equals("admin123"))
			{
				return "adminMenu";
			}
			else
			{
				usr = mgs.fetchManager(user.getUserName());
				if(usr.getUserName().equals(user.getUserName()) && (usr.getUserPswd().equals(user.getUserPswd())))
				{
					return "managerMenu";
				}
				else
				{
					return "login";
				}
			}
			}
	}
	
	//ADMINMENU (ADD)
	
	@RequestMapping("add")
	public String AddTrainee(Model model)
	{
		Asset asset = new Asset();
		model.addAttribute("asset",asset);
		return "addAsset";
	}
	
	@RequestMapping("addAsset")
	public String showAddMenu(@ModelAttribute("asset")Asset asset,Model model)
	{
			ads.addAsset(asset);;
			model.addAttribute("asset",asset);
			return "adminMenu";
	}
		
	
	
	
	
	
	
	
	
	
}
