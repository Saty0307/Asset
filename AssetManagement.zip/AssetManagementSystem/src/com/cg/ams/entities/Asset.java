package com.cg.ams.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="")
public class Asset 
{
	@Id
	@Column(name="")
	private Integer assetID;
	@Column(name="")
	private String assetName;
	@Column(name="")
	private String assetDes;
	@Column(name="")
	private Integer quantity;
	@Column(name="")
	private String Status;
	public Integer getAssetID() {
		return assetID;
	}
	public void setAssetID(Integer assetID) {
		this.assetID = assetID;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetDes() {
		return assetDes;
	}
	public void setAssetDes(String assetDes) {
		this.assetDes = assetDes;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	@Override
	public String toString() {
		return "Asset [assetID=" + assetID + ", assetName=" + assetName + ", assetDes=" + assetDes + ", quantity="
				+ quantity + ", Status=" + Status + "]";
	}
	
	
	
}
