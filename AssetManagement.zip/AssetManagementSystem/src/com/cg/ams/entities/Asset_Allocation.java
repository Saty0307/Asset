package com.cg.ams.entities;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="")
public class Asset_Allocation 
{
	@Id
	@Column(name="")
	private Integer allocationId;
	@Column(name="")
	private Integer assetId;
	@Column(name="")
	private Integer empId;
	@Column(name="")
	private Date allocation_Date;
	@Column(name="")
	private Date release_Date;
	public Integer getAllocationId() {
		return allocationId;
	}
	public void setAllocationId(Integer allocationId) {
		this.allocationId = allocationId;
	}
	public Integer getAssetId() {
		return assetId;
	}
	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public Date getAllocation_Date() {
		return allocation_Date;
	}
	public void setAllocation_Date(Date allocation_Date) {
		this.allocation_Date = allocation_Date;
	}
	public Date getRelease_Date() {
		return release_Date;
	}
	public void setRelease_Date(Date release_Date) {
		this.release_Date = release_Date;
	}
	@Override
	public String toString() {
		return "Asset_Allocation [allocationId=" + allocationId + ", assetId=" + assetId + ", empId=" + empId
				+ ", allocation_Date=" + allocation_Date + ", release_Date=" + release_Date + "]";
	}
	
	
	
}
