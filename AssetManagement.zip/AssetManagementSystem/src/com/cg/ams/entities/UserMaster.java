package com.cg.ams.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

public class UserMaster 
{
	
	@NotNull(message="Cannot be Empty")
	private String userName;
	
	@NotNull(message="Cannot be Empty")
	private String userPswd;
	
	@NotNull(message="Cannot be Empty")
	private String userType;
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPswd() {
		return userPswd;
	}
	public void setUserPswd(String userPswd) {
		this.userPswd = userPswd;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	@Override
	public String toString() {
		return "UserMaster [userName=" + userName + ", userPswd=" + userPswd + ", userType=" + userType + "]";
	}
	 
	
}
