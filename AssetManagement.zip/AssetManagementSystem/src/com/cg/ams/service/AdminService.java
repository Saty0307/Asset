package com.cg.ams.service;

import java.util.List;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.Asset_Allocation;

public interface AdminService 
{
	void addAsset(Asset ast);
	 void delAsset(Integer astId);
	 Asset modAsset(Asset ast);
	 Asset fetchAsset(Integer ast);
	 List<Asset_Allocation>fetchAllAssetAllocation();
}
