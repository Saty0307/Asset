package com.cg.ams.service;

import java.util.List;

import com.cg.ams.entities.Asset;
import com.cg.ams.entities.UserMaster;


public interface ManagerService 
{
	void reqAsset(Integer astId);
	List<Asset> fetchRequestStatus();
	UserMaster fetchManager(String mgrname);
}
