package com.cg.ams.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ams.dao.ManagerDao;
import com.cg.ams.entities.Asset;
import com.cg.ams.entities.UserMaster;


@Transactional
@Service
public class ManagerServiceImpl implements ManagerService 
{
	@Autowired
	ManagerDao mgo;

	@Override
	public void reqAsset(Integer astId) 
	{
		mgo.reqAsset(astId);
		
	}

	@Override
	public List<Asset> fetchRequestStatus() 
	{
		
		return mgo.fetchRequestStatus();
	}

	@Override
	public UserMaster fetchManager(String mgrname) 
	{
		 return mgo.fetchManager(mgrname);
	}

}
