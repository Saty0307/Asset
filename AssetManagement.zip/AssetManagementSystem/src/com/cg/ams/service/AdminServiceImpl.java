package com.cg.ams.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.ams.dao.AdminDao;
import com.cg.ams.entities.Asset;
import com.cg.ams.entities.Asset_Allocation;

@Transactional
@Service
public class AdminServiceImpl implements AdminService 
{
	@Autowired
	AdminDao ado;

	@Override
	public void addAsset(Asset ast) 
	{
		ado.addAsset(ast);
		
	}

	@Override
	public void delAsset(Integer astId) 
	{
		ado.delAsset(astId);
		
	}

	@Override
	public Asset modAsset(Asset ast) 
	{
		
		return ado.modAsset(ast);
	}

	@Override
	public Asset fetchAsset(Integer ast) 
	{
		
		return ado.fetchAsset(ast);
	}

	@Override
	public List<Asset_Allocation> fetchAllAssetAllocation() {
		
		
		return ado.fetchAllAssetAllocation();
	}
	
}
